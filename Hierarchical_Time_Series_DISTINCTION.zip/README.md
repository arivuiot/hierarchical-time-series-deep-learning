Advanced Hierarchical Time Series Forecasting (Distinction Level)
SKU → Store → Region
Multi-horizon LSTM, ETS baseline, rolling-origin CV
